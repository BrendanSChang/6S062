#import <XCTest/XCTest.h>

@interface CPTTestCase : XCTestCase

@end
