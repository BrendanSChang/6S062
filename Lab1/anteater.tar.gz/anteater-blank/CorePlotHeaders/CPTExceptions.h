/// @file

/// @name Custom Exception Identifiers
/// @{
extern NSString *__nonnull const CPTException;
extern NSString *__nonnull const CPTDataException;
extern NSString *__nonnull const CPTNumericDataException;
/// @}
