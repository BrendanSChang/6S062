//
//  LeaderboardViewController.h
//  Anteater
//
//  Created by Sam Madden on 1/23/16.
//  Copyright © 2016 Sam Madden. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeaderboardViewController : UITableViewController

@end
