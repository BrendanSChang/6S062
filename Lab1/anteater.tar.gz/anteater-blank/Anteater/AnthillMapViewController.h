//
//  AnthillMapViewController.h
//  Anteater
//
//  Created by Sam Madden on 1/13/16.
//  Copyright © 2016 Sam Madden. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AnthillMapView.h"
@interface AnthillMapViewController : UIViewController

 @property(atomic) IBOutlet AnthillMapView *map;

@end

