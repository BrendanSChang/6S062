//
//  LeaderboardCell.m
//  Anteater
//
//  Created by Sam Madden on 1/23/16.
//  Copyright © 2016 Sam Madden. All rights reserved.
//

#import "LeaderboardCell.h"

@implementation LeaderboardCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
